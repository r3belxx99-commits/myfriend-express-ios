# My Friend! Express — Paket sumber iOS 1.0

## Isi dan batasan
Paket ini berisi proyek Xcode iOS yang sudah dibuat, ikon aplikasi, izin lokasi berbahasa Inggris/Khmer, halaman tanpa internet, konfigurasi Capacitor 8.5.3, dan panduan pengujian. Tata letak toko tidak diubah.

Ini **paket sumber untuk uji coba**, bukan berkas IPA yang sudah ditandatangani, dan belum diuji di iPhone atau disetujui Apple. Aplikasi memuat layanan aktif di https://app-storefront-guide.lovable.app. Katalog, akun, pesanan, promo, pembayaran yang tersedia, dan pengelolaan tetap berjalan melalui layanan tersebut. Tidak ada salinan data pelanggan, kata sandi, kunci rahasia, maupun database di ZIP ini. Data tersimpan di layanan yang sudah digunakan; riwayat/keranjang lokal di browser tidak otomatis pindah ke instalasi iOS baru.

Koneksi internet wajib. Halaman lokal saat internet terputus bukan dukungan belanja offline. Ikon 1024×1024 diperbesar dari ikon aplikasi yang tersedia; untuk pengajuan final sebaiknya gunakan gambar asli resolusi tinggi.

**Penting:** `server.url` merupakan jalur pemuatan jarak jauh yang didokumentasikan Capacitor terutama untuk live reload, bukan rekomendasi produksi. Paket ini sengaja memakainya agar aplikasi TanStack Start yang memerlukan layanan server tetap bisa dicoba. Sekadar membungkus situs berisiko ditolak menurut pedoman Apple 4.2. Untuk versi produksi yang lebih kuat, perlu pekerjaan lanjutan mengemas tampilan lokal dan menghubungkannya ke layanan server, serta menguji fitur iPhone. Proses ini tidak diselesaikan oleh paket ini dan kelulusan tidak dijamin.

## Yang dibutuhkan
- Mac dengan Xcode 26 atau lebih baru yang didukung Capacitor 8; periksa persyaratan SDK Apple terbaru ketika mengunggah.
- Node.js 22 atau lebih baru, npm, dan koneksi internet untuk mengambil paket Swift.
- iPhone untuk pengujian nyata; akun Apple Developer berbayar untuk TestFlight/App Store.
- Aplikasi di alamat terbitan harus aktif dan dapat dibuka publik tanpa akun Lovable. Perubahan aplikasi di Lovable perlu diterbitkan terpisah; ZIP ini tidak menerbitkannya.

## Membuka dan menjalankan
1. Ekstrak ZIP ke Mac.
2. Buka Terminal di folder hasil ekstraksi, lalu jalankan:
   ```sh
   npm install
   npm run ios:sync
   npm run ios:open
   ```
   Proyek `ios/App/App.xcodeproj` sudah tersedia; **tidak perlu** menjalankan `cap add ios` lagi. Xcode dapat dibuka langsung melalui berkas ini; perintah sinkronisasi menyalin halaman lokal dan konfigurasi.
3. Di Xcode, pilih target **App → Signing & Capabilities** dan pilih Team milik Anda. Aktifkan Automatically manage signing.
4. Identifier sementara adalah `com.myfriendexpress.store`. Konfirmasikan ketersediaannya pada akun Apple Anda sebelum membuat rekaman aplikasi. Bila berubah, ubah `appId` dalam `capacitor.config.json` **dan** Bundle Identifier pada Xcode; sinkronisasi saja tidak mengganti identifier target lama.
5. Pilih perangkat iPhone atau simulator lalu tekan Run. Pengaturan target bawaan mendukung iOS 15+; simulator bukan pengganti pengujian lokasi, telepon, dan Telegram pada perangkat nyata.
6. Periksa versi 1.0/build 1 dan atur sendiri nomor build berikutnya sebelum unggah.

## Pengujian wajib sebelum TestFlight
Tandai hanya setelah benar-benar berhasil pada iPhone:
- [ ] Toko dan semua gambar terbuka; kedua bahasa, tab, keyboard, poni layar, ukuran tulisan, dan landscape terbaca.
- [ ] Tamu menambah barang, membuka keranjang, memberikan lokasi, dan mengirim pesanan uji; pesanan dibaca kembali oleh pemilik dan melalui tracking.
- [ ] Pemberian izin lokasi berhasil setelah mengetuk tombol; penolakan izin memberi pesan yang jelas. Memasang izin di Info.plist tidak membuktikan `navigator.geolocation` bekerja dalam WKWebView.
- [ ] Email kode, pendaftaran, login password, pindah ke Mail lalu kembali, reload, logout, dan keranjang antar akun berfungsi.
- [ ] Penghapusan akun bekerja; lakukan hanya pada akun uji yang disetujui, bukan akun pemilik/pelanggan.
- [ ] Nomor tracking valid/tidak valid, daftar pesanan, promo, dan perubahan status pemilik terbaca kembali.
- [ ] Call us membuka konfirmasi telepon pada iPhone; Telegram membuka aplikasi atau Safari jika tidak terpasang.
- [ ] Internet terputus menampilkan halaman lokal, tombol Try again pulih setelah internet kembali.
- [ ] Tutup/buka aplikasi mempertahankan sesi sesuai aturan, tanpa menampilkan data akun lain.

Capacitor 8.5.3 menyertakan penanganan navigasi eksternal: tautan luar dan `tel:` diteruskan ke iOS, tanpa daftar izin wildcard. Perilaku handoff ini belum diuji pada perangkat. Login saat ini mengikuti alamat web aktif; paket ini tidak menambahkan OAuth atau skema deep-link baru. Bila login sosial ditambah nanti, callback perlu pekerjaan dan uji khusus.

## Privasi dan pengajuan Apple
- Deklarasi izin lokasi hanya When In Use; tidak ada permintaan lokasi latar belakang, kamera, pelacakan iklan, maupun push yang ditambahkan.
- Capacitor membawa manifest privasi SDK-nya. Jangan menganggapnya sebagai deklarasi semua data toko: periksa laporan privasi arsip Xcode dan lengkapi App Privacy untuk nama, email, telepon, alamat/lokasi, ID akun, riwayat pembelian dan layanan penerima data yang benar-benar digunakan, termasuk pengiriman rincian pesanan ke Telegram. Tentukan status “linked to user” sesuai perilaku aktual.
- Teks izin lokasi berisi Inggris dan Khmer dalam satu pesan; pastikan keduanya terbaca saat permintaan izin pada iPhone.
- Siapkan nama/deskripsi, kategori, negara distribusi, umur, URL privasi `https://app-storefront-guide.lovable.app/privacy`, URL bantuan `https://app-storefront-guide.lovable.app/help`, gambar layar dari aplikasi iOS final, dan akun pemeriksa bukan akun admin. Pastikan kedua URL dapat diakses publik dan isinya akurat sebelum pengajuan.
- Isi catatan review: aplikasi belanja barang fisik, wilayah pengantaran yang benar-benar tersedia, langkah uji checkout, cara membagikan lokasi, metode pembayaran nyata, cara menghapus akun, serta informasi akses yang diperlukan. Jangan mengarang metode pembayaran atau lokasi toko.
- Pilih **Product → Archive**, kemudian **Distribute App → App Store Connect**. Jalankan TestFlight terlebih dahulu dan perbaiki temuan sebelum **Submit for Review**.

## Hasil pemeriksaan paket
Proyek Xcode dihasilkan oleh Capacitor CLI dan konfigurasi, plist, ikon, versi dependensi, serta keamanan isi arsip diperiksa di lingkungan Linux. Kompilasi Swift, penandatanganan, IPA, alur pesanan di WKWebView, dan TestFlight **belum diverifikasi** karena memerlukan Mac/iPhone serta akun Apple milik Anda.

## Referensi resmi
- https://capacitorjs.com/docs/getting-started/environment-setup
- https://capacitorjs.com/docs/config
- https://capacitorjs.com/docs/ios
- https://developer.apple.com/app-store/review/guidelines/
- https://developer.apple.com/app-store/app-privacy-details/
